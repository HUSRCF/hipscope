#!/usr/bin/env bash
# Local test driver; each command retains its own original log and exit code.
set -u
cd /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-xts-combined-pr
export ROCR_VISIBLE_DEVICES=-1 HIP_VISIBLE_DEVICES=-1
export CARGO_BUILD_JOBS=8 RUST_TEST_THREADS=1
export PYTHONSAFEPATH=1 PYTHONPATH="$PWD"
out="$PWD/results/xts-combined-pr"
run_check() {
    local name="$1"
    shift
    "$@" > "$out/$name.log" 2>&1
    local status=$?
    printf '%s\n' "$status" > "$out/$name.exit"
    printf '%s exit=%s\n' "$name" "$status"
}
run_check raster cargo test --locked -p hipfire-isa --features toolchain --test v2c_raster
run_check builder cargo test --locked -p hipfire-isa --features toolchain --test gfx11_builder
run_check no-gpu bash scripts/no-gpu-ci.sh
run_check workspace cargo test --locked --lib --workspace

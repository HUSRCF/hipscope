#!/usr/bin/env bash
set -euo pipefail
cd /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-xts-combined-pr
source scripts/gpu-lock.sh
GPU_LOCK_TIMEOUT=10 gpu_acquire xts-pr-serve 0000:53:00.0
trap gpu_release EXIT
while read -r name; do
    case "$name" in HIPFIRE_GPU_LOCK*|HIPFIRE_LOCK_DIR) ;; *) unset "$name";; esac
done < <(compgen -v HIPFIRE_)
out="$PWD/results/xts-combined-pr/serve-corrected"
mkdir "$out"
export ROCR_VISIBLE_DEVICES=0 HIP_VISIBLE_DEVICES=0 HIPFIRE_LOCAL=1
export HIPFIRE_DAEMON_BIN="$PWD/target/release/daemon"
export HIPFIRE_CLI_BIN="$PWD/target/release/hipfire"
export HIPFIRE_KERNEL_CACHE="$PWD/results/xts-combined-pr/kernel-cache"
export HIPFIRE_DPM_WARMUP_SECS=10 HIPFIRE_QWEN_PROMPT_CACHE=0
export HIPFIRE_REPLAY_BACKEND=redline HIPFIRE_REPLAY_TRANSPORT=pm4
export HIPFIRE_GRAPH=1 HIPFIRE_AR_GRAPH=1 HIPFIRE_REPLAY_PM4_DYNAMIC_GRID=0
md5sum "$HIPFIRE_DAEMON_BIN" "$HIPFIRE_CLI_BIN" > "$out/binary.md5"
set +e
timeout 1800s python3 scripts/serve_harness.py \
    --model /home/husrcf/.hipfire/models/qwen3.8-27b.mq4-xts \
    --speculation off --mtp off --dflash off --thinking off --sampling greedy \
    --kv q8 --kv-backend vmm --max-seq 65536 --max-tokens 1024 --mode battery \
    --home "$out/home" --port 18040 --serve-log "$out/serve.log" \
    --out "$out/battery.json" > "$out/harness.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/exit"
exit "$status"

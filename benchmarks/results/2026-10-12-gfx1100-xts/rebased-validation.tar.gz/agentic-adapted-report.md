# Agentic gate

- commit: 1cdac8a53
- branch: perf/gfx1100-xts-combined
- date:   2026-10-12T10:09:15+08:00
- mode:   fast
- cells:  1

Hard-fail predicates:
- daemon panic / zero tokens / timeout
- tool_call body fails JSON parse
- parsed JSON missing required field (name or arguments)
- special-token leak inside tool_call body (<|im_start|>, <|endoftext|>)
- stacked openers (two consecutive <tool_call>)
- soft-warn count > 1 across all cells

Soft-warn signals (printed, included in collective threshold):
- <tool_call> not emitted (model answered inline)
- <tool_call> appearing inside <think>...</think>

## qwen3.6-27b

### 3.6_hermes_unclamped    PASS

- system: `benchmarks/prompts/agentic_hermes_system.txt` (3132 bytes)
- thinking: unclamped
- multi-turn: no
- notes: json ok: name='read'

```
<tool_call>
{"name": "read", "arguments": {"path": "/tmp/fibonacci.c"}}
</tool_call>
```

## Summary

- total cells: 1
- hard fails: 0
- soft warns: 0

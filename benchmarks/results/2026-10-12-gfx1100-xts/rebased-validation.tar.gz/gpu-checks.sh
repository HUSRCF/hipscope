#!/usr/bin/env bash
set -euo pipefail
cd /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-xts-combined-pr
source scripts/gpu-lock.sh
GPU_LOCK_TIMEOUT=10 gpu_acquire xts-pr-head-checks 0000:53:00.0
trap gpu_release EXIT
while read -r name; do
    case "$name" in HIPFIRE_GPU_LOCK*|HIPFIRE_LOCK_DIR) ;; *) unset "$name";; esac
done < <(compgen -v HIPFIRE_)
export ROCR_VISIBLE_DEVICES=0 HIP_VISIBLE_DEVICES=0
out="$PWD/results/xts-combined-pr"
export HIPFIRE_DAEMON_BIN="$PWD/target/release/daemon"
export HIPFIRE_CLI_BIN="$PWD/target/release/hipfire"
export HIPFIRE_HOME="$out/runtime-home" HIPFIRE_KERNEL_CACHE="$out/kernel-cache"
export HIPFIRE_DPM_WARMUP_SECS=10 HIPFIRE_MODULE_LOAD_AUDIT=1
export HIPFIRE_QWEN_PROMPT_CACHE=0 HIPFIRE_REPLAY_PM4_DYNAMIC_GRID=0
export HIPFIRE_REPLAY_BACKEND=pm4
md5sum "$HIPFIRE_DAEMON_BIN" "$HIPFIRE_CLI_BIN" > "$out/binary.md5"
git diff --binary > "$out/tested-source.patch"
git rev-parse HEAD > "$out/tested-base.txt"
set +e
timeout 1800s python3 scripts/redline_daemon_harness.py \
    --model /home/husrcf/.hipfire/models/qwen3.8-27b.mq4-xts \
    --daemon "$HIPFIRE_DAEMON_BIN" --kv-mode q8 --max-seq 65536 \
    --prefill 512 --decode-context 32704 --capture-repeats 2 --measure-repeats 2 \
    --decode-iterations 16 --shadow-iterations 8 --shadow-position-step 64 \
    --pm4 --timeout 600 --out "$out/runtime.json" --log "$out/runtime.log" \
    > "$out/runtime-harness.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/runtime.exit"
if [ "$status" -ne 0 ]; then exit "$status"; fi
unset HIPFIRE_MODULE_LOAD_AUDIT
timeout 1800s python3 scripts/serve_harness.py \
    --model /home/husrcf/.hipfire/models/qwen3.8-27b.mq4-xts \
    --speculation off --mtp off --dflash off --thinking off --sampling greedy \
    --kv q8 --kv-backend vmm --max-seq 65536 --max-tokens 1024 --mode battery \
    --home "$out/serve-home" --port 18040 --serve-log "$out/serve.log" \
    --out "$out/battery.json" > "$out/serve-harness.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/serve.exit"
exit "$status"

# 三优化组合 PR 准备审计（2026-10-12）

状态：**源码边界已核对；仅为本地 PR 准备，不是合并就绪或发布声明。**
本轮只读检查源码、补丁、哈希与已有报告，未运行 GPU、未重新构建、未提交、未发布。
本文唯一新增文件；当前脏工作区的其他实验保持原样。

用户要求的顺序是：原始 beta A 对三优化组合 B 测速度 → 只跑 B 的
LongBench → 准备 PR。以下历史分项证据不能替代这次组合测量。
本文写入时，新组合性能/LongBench 结果由主执行流程单独整理，不在这里预填通过。

## 1. A/B 身份与来源

| 项目 | 本轮 A：原始 beta | 本轮 B：raster4 + half-V + HIN one-pass |
|---|---|---|
| 生产源码基线 | `6d71d955e711dc816aa87f066364a8b59545bb76` | `38d77049593e7c92f4d86995d98fe5aaa1c8b492` + 三份冻结补丁 |
| daemon | `results/xts-prefill-20261011/frozen-beta-bin/daemon` | `results/xts-prefill-20261011/hin-integration/build-1/binB/daemon` |
| daemon MD5（本轮实算） | `7d191dfa5e66552e798739be624f20b5` | `1940c6b40973e389067448b6e7177518` |
| 各自 CLI MD5（本轮实算） | `c139784cda61caa3ccaebbd49fcbce6c` | `b4416f8c55ec861cd69f44f4a2bcc7ae` |

注意：旧 HIN 实验 `build-1/binA/daemon` 的 MD5 是
`fd7418cb9b98426cd5b3dbc2d3b63289`，它已带 raster4 + half-V，**不是本轮 A**。
旧 HIN 实验共同 CLI 是 `788307b52efb83de93ff16fbbca39040`。
若新性能流程共用某个 CLI，必须记录实际选用的路径/哈希，不能照抄上表的各自 CLI。

### beta 到隔离构建基线

`git merge-base --is-ancestor <beta> <38d770495>` 成功。
`git diff --name-only <beta> <38d770495>` 共 151 个文件：

| 路径前缀 | 数量 | 性质 |
|---|---:|---|
| `benchmarks/` | 1 | prompt fixture |
| `dse_results/` | 8 | 实验结果、解析器与图 |
| `experiments/` | 119 | 报告、实验脚本、CPU/GPU oracle 与测试 |
| `results/` | 23 | 归档与候选补丁 |

`crates/`、`kernels/`、`Cargo.toml`、`Cargo.lock`、`.cargo/`、`scripts/`
在此区间无差异。准确说法是“生产源码无变化”，而不是“只有文档变化”。
整个实验分支的 151 文件历史不应作为最小 production PR 的差异面。

### 隔离 B 的逐文件审计

直接读取 `build-1/source/`，用 Git blob SHA-1 算法重新散列文件，逐项对照
`git ls-tree -rz 38d770495...`。重现构建脚本的 tar 排除语义：任何路径组件
名为 `results` / `dse_results` 都排除，而非只排除根目录。

- 期望 6,066 个文件，实际 6,066 个；无额外文件、无缺失文件。
- 6,062 个文件逐字节匹配基线；仅下表 4 个文件不同。
- 与保存的 `source-A-manifest.json` 对照，仅 `crates/rdna-compute/src/kernels.rs`
  不同，符合旧 HIN A → B 仅增加 one-pass 前缀的合同。
- 三份冻结补丁的 MD5 与 `stage-report.json` 一致。
- 在隔离 source 内、设置 `GIT_CEILING_DIRECTORIES` 到其父目录后执行
  `git apply --check --reverse ../hin-only.patch ../half-v.patch ../raster.patch`
  成功；没有实际应用/反向修改文件。

| 生产文件 | beta MD5 | 隔离 B MD5 |
|---|---|---|
| `crates/hipfire-isa/src/kernels/iu4_v2c.rs` | `42e68b2a803e2d72e04e4ea91329cec5` | `75ba7bcb7f858d4295f21eeb5ae9add3` |
| `crates/rdna-compute/src/kernels.rs` | `f95c38be5cb89ac499a5a60ef952f5d7` | `d6c623664a2f07383f056afaa3fe1100` |
| `kernels/gemm_mq4g256v2_residual_iu4_pm_gfx1100.hxaco` | `eb9f43dadb8e2e3035c56d0e5907064a` | `639a28e154c179525af426b4cd8d0f42` |
| `kernels/src/attention_flash_q8_0_tile_gqa.gfx1100.hip` | `782d2c03f2d8e08444d2ae2cc0bf4db3` | `238901bd90ca4fdfbfa94ed2980ef543` |

冻结补丁都位于 `results/xts-prefill-20261011/hin-integration/build-1/`：

| 补丁 | MD5 | 范围 |
|---|---|---|
| `raster.patch` | `2cb98e352a8d19b1af44ec6e02025f00` | generator、gfx1100 bundle、bundle 来源注释 |
| `half-v.patch` | `fd968ebfe10ae21bf89fa2a16ab46ed4` | 单个 GQA attention HIP 文件 |
| `hin-only.patch` | `7c989bfff3acb33a6378cbc2e96d7fb9` | HIN concat 常量的一行条件宏前缀 |

gfx1100 bundle SHA-256 为
`56b49afb87007ebf81bc23f87092cd3baa92d5a5e1e7d7c9743371b62f506289`。
隔离构建报告记录 `cargo build --release --locked --offline -p hipfire-daemon
-p hipfire-cli` 成功；这不是完整 workspace/all-targets 构建通过。

## 2. 最小 production diff 与排除项

建议从明确的目标 beta 基点准备独立干净 PR 分支/工作树，只选择上面三份补丁，
再加入必要测试和紧凑证据。不要整分支合并、不要 `git add .`，也不要从当前
脏 `kernels.rs` 直接复制；该文件同时有其他实验修改，HIN 只存在于冻结隔离版本。
本轮没有创建分支或执行上述组装操作。

三项行为变化：

1. raster4：gfx1100 V2C 完整 4×4 tile 组且 N≥4096 时交换低两位坐标；
   短/不完整网格保持线性。generator 与嵌入 bundle 必须一起提交，不能只交二进制。
2. half-V：Q8 GQA attention 的 V staging 分为 64-key slab；在 slab 重用前后
   保留同步与局部索引，保持累加顺序。没有新增生产全局 device buffer。
3. HIN：仅 `__gfx1100__ && IU4_A4_CANDIDATES == 2` 定义
   `HIPFIRE_IU4_C2_ONEPASS`；其他候选数/架构不启用该前缀。

以下当前 dirty 文件/功能**不在组合候选中**，禁止顺手带入：
`hipfire-arch-qwen35/.../forward.rs`、`hipfire-dispatch/.../attention.rs`、
`rdna-compute/{kernel_registry.rs,lib.rs,replay.rs,qwen35_fa_cache.rs}`、
`kernels/src/qwen35_fa_prep.gfx1100.hip`、`docs/env-vars.md`，以及 FA cache
fusion、dynamic-grid、其他 decode 参数探索。当前工作树与冻结版本的同名文件
也不能仅凭名字视为相同。

half-V 冻结补丁仍有 `Experimental64-token...` 及过时 full-V 注释；生产 PR
应只做必要的注释/排版清理，保留 SPDX/版权行。后续报告已记录清理注释后
attention ELF 仍为 `01251192caaef8be7e9216cfaacc6341`，但提交前仍须把最终
文本、构建输出和本轮实测二进制的对应关系说明白。不要用新文件哈希冒充冻结哈希。

### 测试最小集合

- 纳入 `crates/hipfire-isa/tests/v2c_raster.rs`：实际解释 emitted ISA，覆盖
  270 组网格、三种 epilogue、阈值/回退、双射与非临时 SGPR 保持。
- 保留已有 `gfx11_builder` fresh-emission/bundle equality/certification 测试；
  不需要复制修改该测试文件来制造“新增覆盖”。
- half-V 保留独立 oracle 的 63/64/65/127/128 slab 边界、尾部及 CTA reuse
  覆盖；`attention_heads_oracle.cpp` 的 `ATTENTION_GRID_REUSE_ONLY` 已有两卡
  30/30 exact 记录。CPU source-transform 测试不是数值正确性的替代品。
- HIN 保留条件宏 admission/重复应用拒绝测试、局部输出/guard oracle，以及
  gfx1100 C1/C8、gfx1151 C2、gfx1201 C2 不变的编译对象证据。现有
  `test_hin_integration_build.py` 检查的是实验变换器，不是未来提交的生产常量；
  PR 最好有直接读取最终常量的窄 scope 测试，避免“测试生成器但生产没接上”。
- 测量 runner/汇总器的测试只按复现所需带入。现有 `test_hin_serve.py` 依赖
  half-V runner/tests；不要只挑单个测试而漏依赖，也无需把所有失败候选的脚本
  都纳入 production PR。证据包可独立保存并由 PR 链接其 hash。

以上为准备建议，未在本轮新增或执行这些测试。

### 最新 upstream beta 的移植检查

主流程只读查询并 fetch 后，本轮读到 `FETCH_HEAD` 为
`3160de33d6f67550e4dc51af98873df63d686aec`（`chore(maps): regenerate`）。
它比冻结测试 beta 前进 142 commits，总差异 407 files、+120773/−7692 行。
**本轮固定 A/B 不随 upstream 漂移；最新 upstream 也不是本轮性能 A。**

对三优化涉及的四个文件：generator、gfx1100 bundle、attention HIP 三者
与冻结 beta 完全相同，说明 raster4 与 half-V 尚未在此 beta 合入；
`kernels.rs` 上游 +86/−1 行主要是其他 kernel 的常量/来源说明，HIN 条件宏
仍未加入。已核对 HIN 两个 include 文件 `block_i4_128_quant.hip` 与
`fused_silu_mul_mq_rotate_awq.hip` 未变。

没有创建最新 beta 工作树，也没有写生产文件。在内存中逐 hunk 检查并应用
`kernels.rs` 的 raster/HIN 补丁：完整旧上下文各唯一匹配，raster hunk 起点从
4621 移到 4680，HIN hunk 仍在 1943；预测该文件 patch 后 MD5 为
`a6b16e936ace548d0bad4d6cbcb825a0`。其余三文件是相同基线字节，结合已通过的
冻结补丁检查，未发现机械移植冲突。此项是 **read-only context/hash 检查**，
不冒充对实际最新工作树运行了完整 `git apply --check` 或构建。

移植的文本冲突风险低，但运行时证据不能自动继承。上游还改了 `Cargo.lock`、
多个 daemon/runtime/dispatch/compute 文件；Qwen35 forward 变化经查看是
MoE dump 与 fence 注释，不是本任务三优化，不能从“同名文件变了”推断本
dense 路线一定受影响，也不能据此断言整个调用路径不变。
AGENTS、CLAUDE、PR 模板与 pre-commit 文件未变；VALIDATION 新增了别的
pilot/shared-weight 路线，本任务的既有路线要求未改变。

因此最终 PR 若基于最新 beta，应把旧 beta→组合实验标为 **历史、固定基点
证据**。最新 beta 与最新 beta+三补丁的干净构建、最终源码 scope、CPU/门禁、
claim-matched runtime/serve 验证和性能对照尚未完成，不能勾选为已验证。
这些是后续 PR 准备/验证的缺口，不是授权本轮追加另一轮 GPU 实验；也不应
以 beta 历史的巨大差异作为 production PR 内容。

## 3. 已有证据：可以引用，但不可混淆对照

| 优化/证据 | 已有结论 | 限制 |
|---|---|---|
| raster4，`embedded-results.md` | 原始 beta 对 raster4：PP4096 +1.392%、PP8192 +2.017%；TG256@8192 −0.076%；18+1 builder/raster tests | synthetic device timing，不是 HTTP TTFT；只有 raster4 |
| raster4 runtime/quality | PP512 与 ctx8192 retained capture/合同/shadow 通过；LongBench30 全文本同历史 A | PP8192 retained capture 超 recorder 容量；同样 3 attractor/5 capped，stock exit1 |
| half-V，`dse_results/half-v-serve/DSE_REPORT.md` | 两卡真实服务 decode 中位数各 +0.7833%；正式 12 cells stock pass，完整文本相同 | A 已有 raster4；重复请求命中 16K prefix，不能作 cold-prefill 对照 |
| half-V runtime/oracle | HIP/PM4/blob parity 通过；CTA reuse + slab-tail 30/30 exact | 不是全模型/所有输入质量保证；LDS 减少不是 VRAM 节省 |
| HIN，`dse_results/hin-serve/REPORT.md` | A=raster4+half-V，B=三优化；两卡 prefill +0.724%/+0.515%，decode 基本持平 | 23,972-token 单故事、1024 上限、3 次/臂；不能与 half-V prefill 混比 |
| HIN runtime/加载 | runtime 46 模块、serve 37 模块仅 HIN ELF 不同；28 次完整解析文本相同；stock pass | 跨卡 runtime 仅作正确性；旧 HIN 轮没跑 LongBench |

分项百分比**不能相加**成为 beta→组合收益；必须以新 A/B 数据为准。
HIN 局部约 28% 也不能当整模型提速。已有所有结果仅绑定两张 W7900/gfx1100、
Qwen3.8-27B MQ4-XTS、相应 Q8/VMM/AR 配置，不声称跨架构速度收益。

原始证据包 SHA-256（引用历史报告；本轮未重新解包验证全部成员）：

- raster4：`69cf5475fe9f51ad32d8e6c72fa7bbb6dc9769cf04b2869466691a8ac1d3ed09`。
- half-V serve：`3731f336bcf7e6d222f83fcc97f07be0a8db6e9a3b23dc7655c4f8904e04f082`。
- HIN serve：`62c58179f7fa24055655905cceacd144cf91cf7a46c0af2ef185eaf3efc2e3dd`。

## 4. PR 模板证据与阻塞

按 `.github/PULL_REQUEST_TEMPLATE.md` 勾选 **kernel**；不要勾“docs only”。
生产 diff 不改 Architecture trait、CLI、registry、模型加载行为或 arch crate。
自动 bucket 的 kernel 同时蕴含 load 验证，并不表示 PR 改了模型加载代码。
`docs/VALIDATION.md` 要求 claim-matched kernel oracle、模型 serve 检查、
retained capture/合同/parity，以及性能协议；LongBench 不是这些路线的替代品。

| 模板/要求 | 当前证据或缺口 |
|---|---|
| 精确源码与二进制 | 本文全量文件审计及实算 MD5 已有 |
| 产品 release 构建 | 隔离 daemon/CLI 构建报告已有；最终 PR 工作树须重验 |
| no-GPU CI | raster 阶段 safe-path、允许本地 socket 的运行曾成功；不等于最终组合 PR 的 CI green |
| `cargo test --lib --workspace` | 未全绿；历史串行 4,721 passed / 3 failed / 73 ignored；两项 ISA 硬编码 `/home/kaden` 路径，一项 sandbox socket；早期并行 Qwen4 SIGSEGV 未定因 |
| 格式/提交门禁 | generator 格式债清理预览 +1212/−244 行，`kernels.rs` +26/−14；尚未解决，禁止 bare `cargo fmt` 或跳 hook |
| speed-gate 固定 floor | 旧 4B decode 169.1 floor 未达，干净 beta 同样约146 tok/s；这是已有基线差异，非通过，也不能在本 PR 偷改 floor |
| serve harness battery | 三优化 B 已有故事 fixture 成功记录；新 B LongBench 待独立报告。附完整 per-turn JSON/输出，披露 caps/attractor/stock exit；不把单故事视为全覆盖 |
| KV backend 披露 | 新组合 run 必须核对 `kv_backend` / `kv_backend_legacy` / `kv_backend_reason`；若 legacy，按模板写明确/自动及原因，不能只凭 env 推断 |
| beta→组合性能 | 新测量结果待主流程；不可挪用 HIN-only A/B 或带 profile 的 trace timing |
| review / remote | 尚无 PR、无审批；最终需 required CI 与维护者 review，hw-gate 是可选证据，不是自动合并授权 |

旧 4B 故障细节见 `precommit-diagnosis.md`：干净 beta 两卡 control 也失败，
half-V GQA tile 不满足该 4B route 的 admission。此证据支持“不是 half-V 引入的
已证回归”，不支持“正常提交 gate 已通过”。修复脚本、路径/环境、格式债和
baseline 政策应独立说明；不修改断言、不降低阈值、不使用 `--no-verify`。

若最终 clean PR 仅支持一款硬件/fixture，应直接限定声明范围；非目标对象
byte-identical 是 scope 证据，不是那些硬件完成性能/全质量验证。

## 5. 本地 PR 描述骨架（未发布）

建议标题：`perf(gfx1100): combine V2C raster4, half-V attention and HIN one-pass`。

摘要：在 gfx1100 的既有 V2C、Q8 GQA attention 和 HIN C2 路线上分别改进
tile 顺序、V staging 和重复量化工作；不改变其他实验路线或全局配置。

性能段只填新 beta→组合、同卡新进程的原始样本/中位数/散布，区分 prefill、
decode、TTFT；披露 warmup、cache/prefix、生成 cap、路由、模型/prompt/二进制
hash 和传感器缺项。质量段说明“本轮只重跑 B”，若借历史 A 比较，要显式列出
旧 A 身份、相同 fixture/参数及复用性质，不称为新鲜 A/B LongBench。

附上新 B LongBench 全输出/stock JSON、组合源码四文件哈希、三份补丁、已有
数值/retained-route 证据，以及仍未通过的门禁清单。结果尚缺或 gate 失败时
保留 unchecked；用户未授权远程发布，本轮不创建 PR、不推送、不提交。

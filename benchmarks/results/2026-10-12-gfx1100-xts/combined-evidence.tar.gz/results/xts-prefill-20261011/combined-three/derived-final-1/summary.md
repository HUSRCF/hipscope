# Combined-three derived evidence

Read-only snapshot; missing/failed gates are not passes.

## serve: complete

| Metric | A median [min, max] | B median [min, max] | B/A | Delta |
|---|---:|---:|---:|---:|
| vram_peak_bytes | 2.28172e+10 [2.28172e+10, 2.28172e+10] | 2.28172e+10 [2.28172e+10, 2.28172e+10] | 1.000000 | +0.000% |
| vram_peak_MiB | 21760.2 [21760.2, 21760.2] | 21760.2 [21760.2, 21760.2] | 1.000000 | +0.000% |
| decode_tok_s | 38.1 [38.1, 38.2] | 38.4 [38.3, 38.6] | 1.007874 | +0.787% |
| prefill_tok_s | 1802.1 [1798.8, 1809.1] | 1840.2 [1833.5, 1841.8] | 1.021142 | +2.114% |
| prefill_ms | 13302.3 [13251, 13326.8] | 13026.9 [13015.4, 13074.5] | 0.979297 | -2.070% |
| ttft_s | 13.372 [13.32, 13.397] | 13.097 [13.085, 13.144] | 0.979435 | -2.057% |

Raw per-process measurements (warmup excluded):

| cell | arm | vram_peak_bytes | vram_peak_MiB | decode_tok_s | prefill_tok_s | prefill_ms | ttft_s |
|---|---|---|---|---|---|---|---|
| A1 | A | 22817210368 | 21760.1875 | 38.1 | 1809.1 | 13251.0 | 13.32 |
| B1 | B | 22817222656 | 21760.19921875 | 38.3 | 1841.8 | 13015.4 | 13.085 |
| B2 | B | 22817214464 | 21760.19140625 | 38.6 | 1840.2 | 13026.9 | 13.097 |
| A2 | A | 22817210368 | 21760.1875 | 38.1 | 1798.8 | 13326.8 | 13.397 |
| A3 | A | 22817206272 | 21760.18359375 | 38.2 | 1802.1 | 13302.3 | 13.372 |
| B3 | B | 22817218560 | 21760.1953125 | 38.4 | 1833.5 | 13074.5 | 13.144 |

## matrix: complete

| Metric | A median [min, max] | B median [min, max] | B/A | Delta |
|---|---:|---:|---:|---:|
| vram_peak_bytes | 2.18983e+10 [2.18983e+10, 2.18984e+10] | 2.18983e+10 [2.18983e+10, 2.18984e+10] | 1.000000 | +0.000% |
| vram_peak_MiB | 20883.9 [20883.9, 20883.9] | 20883.9 [20883.9, 20883.9] | 1.000000 | +0.000% |
| pp4096_tok_s | 2364.1 [2360.2, 2372.9] | 2423.8 [2422.9, 2424.8] | 1.025253 | +2.525% |
| pp8192_tok_s | 2266.7 [2264.6, 2272.9] | 2327.6 [2325, 2328.3] | 1.026867 | +2.687% |
| tg1024_ctx8192_tok_s | 40.6816 [40.6368, 40.6928] | 40.8308 [40.5429, 40.8552] | 1.003666 | +0.367% |

Raw per-process measurements (warmup excluded):

| cell | arm | vram_peak_bytes | vram_peak_MiB | pp4096_tok_s | pp8192_tok_s | tg1024_ctx8192_tok_s |
|---|---|---|---|---|---|---|
| B1 | B | 21898350592 | 20883.89453125 | 2422.9 | 2325.0 | 40.54286313788642 |
| A1 | A | 21898338304 | 20883.8828125 | 2360.2 | 2264.6 | 40.68162300737074 |
| A2 | A | 21898342400 | 20883.88671875 | 2372.9 | 2272.9 | 40.692772323705704 |
| B2 | B | 21898342400 | 20883.88671875 | 2424.8 | 2327.6 | 40.83076432012387 |
| B3 | B | 21898346496 | 20883.890625 | 2423.8 | 2328.3 | 40.85517998917114 |
| A3 | A | 21898358784 | 20883.90234375 | 2364.1 | 2266.7 | 40.6368367988444 |

## longbench: failed

Stock exit: 1; quality gate: False; transcript equal: True.

| Arm | Recorded | Correct/scored | Attractors | Length-limited |
|---|---:|---:|---:|---:|
| reference | 30/30 | 11/30 | 3 | 5 |
| candidate | 30/30 | 11/30 | 3 | 5 |

## Findings and limits

1. Only complete six-cell arms support the within-instrument median ratios above.
2. Pending/failed/invalid sections do not support a passing campaign or promotion claim.
3. Next: complete missing evidence or diagnose failed gates; investigate deltas ≥5% before attributing them.

- Serving and synthetic matrix are distinct instruments on different GPUs; never pool their measurements.
- B/A > 1 favors B for throughput; B/A < 1 favors B for latency or VRAM. No best-of-one selection.
- VRAM is the whole-card 50ms sampled peak, a lower bound, not allocation accounting; MiB = bytes / 1048576.
- Historical LongBench A binary provenance and original template bytes are incomplete; not a matched timing baseline.
- Stock LongBench failures, attractors, caps and missing rows are not waived by historical parity.
- B's 6066-file source audit against the frozen production baseline found only the four intended production files changed; this is not validation of a rebased latest-beta head.
- Runtime kernel/PM4 identity and general quality require separate evidence; timing does not establish either.
